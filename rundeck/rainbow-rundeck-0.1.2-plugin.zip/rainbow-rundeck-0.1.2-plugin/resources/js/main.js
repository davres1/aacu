jQuery(function () {
    jQuery("body").addClass("rainbow-delite");

    // Build chatbot URL from the Rundeck server hostname (whatever the user used
    // to reach Rundeck), always on port 5000.
    var chatbotUrl = window.location.protocol + "//" + window.location.hostname + ":5000";

    // 1) Override the navbar title/brand link so clicking the Rundeck logo
    //    opens the chatbot in a new tab. Equivalent to rundeck.gui.titleLink
    //    but evaluated per-host in the browser.
    var $brand = jQuery("a.navbar-brand, a#app_logo, a.app-logo").first();
    if ($brand.length) {
        $brand.attr("href", chatbotUrl).attr("target", "_blank").attr("rel", "noopener");
    }

    // 2) Add a dedicated "Chatbot" launcher next to the user menu so it's
    //    discoverable even when the brand link isn't visible.
    if (jQuery("#rainbow-chatbot-link").length === 0) {
        var $btn = jQuery(
            '<li id="rainbow-chatbot-link" class="nav-item">' +
                '<a href="' + chatbotUrl + '" target="_blank" rel="noopener" ' +
                'class="nav-link" title="Open Chatbot (' + chatbotUrl + ')">' +
                '<i class="glyphicon glyphicon-comment" aria-hidden="true"></i> Chatbot' +
                "</a>" +
            "</li>"
        );

        var $nav = jQuery("ul.navbar-nav.navbar-right, ul.nav.navbar-nav.navbar-right, #header_nav .nav.navbar-right").first();
        if ($nav.length) {
            $nav.prepend($btn);
        } else {
            // Fallback: stick it in the top-right of the page
            jQuery("body").append(
                '<a id="rainbow-chatbot-link" href="' + chatbotUrl + '" target="_blank" ' +
                'rel="noopener" ' +
                'style="position:fixed;top:8px;right:12px;z-index:9999;' +
                'background:#337ab7;color:#fff;padding:6px 12px;border-radius:4px;' +
                'text-decoration:none;font-weight:bold;">Chatbot</a>'
            );
        }
    }
});
